✅ Seohee ThemePark (seohee_themepark) - Bokha2 UI 패치(v5)

이 ZIP에는 'parks/seohee_themepark/' 폴더만 들어 있습니다.
- 루트의 assets/, index.html 은 덮어쓰지 마세요.
- 기존 bokha2 스타일(루트 assets/style.css)을 그대로 사용합니다.

설치:
1) theforim.github.io-main/parks/seohee_themepark/ 폴더를 통째로 교체(덮어쓰기)
2) 브라우저 테스트:
   - PowerShell(루트에서): python -m http.server 8010
   - http://127.0.0.1:8010/parks/seohee_themepark/trees/SH-DTAM001.html

Google Form 연결:
- 각 HTML 하단의 FORM_PREFILL_URL에 프리필 URL을 넣으면 '조사기록' 버튼이 그 폼으로 이동합니다.
